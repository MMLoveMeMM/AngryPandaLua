local user = luajava.bindClass("com.lua.data.Users");
local userobj = luajava.new(user)
--�޲κ���
function hello()
print 'hello'
end
--���κ���
function test(str)
print('data from java is:'..str)
return 'haha'
end

function testUser(usr)
userobj = usr
--usr.isuserdata()?usr:nil
print(userobj:getName())
return 'lzb'
end
