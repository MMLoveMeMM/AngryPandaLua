frame = luajava.newInstance("java.awt.Frame", "createProxy test")
local logger_method = luajava.bindClass("com.lua.java.Logger");
exit_bt = luajava.newInstance("java.awt.Button", "Exit")  
frame:setSize(600,500)  
frame:setBounds(50,50, 500,300)
BorderLayout = luajava.bindClass("java.awt.BorderLayout")  

frame:add(BorderLayout.CENTER, exit_bt)
frame:pack()

exit_cb = { actionPerformed =
    function (ev)  
        frame:setVisible(false)  
        frame:dispose()  
        logger_method:info("frame windows exit !")
    end  
}

wm_adapter = { windowClosing = 
    function (args)
      frame:setVisible(false)  
      frame:dispose()  
      logger_method:info("frame windows exit !")
    end
}

exit_jproxy = luajava.createProxy("java.awt.event.ActionListener" ,exit_cb)
exit_bt:addActionListener(exit_jproxy)  

wm_jproxy = luajava.createProxy("java.awt.event.WindowListener" ,wm_adapter)
frame:addWindowListener(wm_jproxy)

frame:show() 


