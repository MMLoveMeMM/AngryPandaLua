local json = require "cjson"
local json_safe = require "cjson.safe"
local util = require "cjson.util"

--ʹ��luajava����java���ʵ��������
local logger = luajava.newInstance("com.lua.java.Logger")

--lua�����ַ���
local obj = {
    id = 1,
    name = "zhangsan",
    age = nil,
    is_male = false,
    hobby = {"film", "music", "read"}
}
 
local str = cjson.encode(obj)
-- ngx.say(str, "<br/>")
logger:testLogger(str)
--�ַ�����lua����
str = '{"hobby":["film","music","read"],"is_male":false,"name":"zhangsan","id":1,"age":null}'
local obj = cjson.decode(str)
 
--ngx.say(obj.age, "<br/>")
--ngx.say(obj.age == nil, "<br/>")
--ngx.say(obj.age == cjson.null, "<br/>")
--ngx.say(obj.hobby[1], "<br/>")
logger:testLogger(obj.age)
logger:testLogger(obj.hobby[1])

--ѭ������
obj = {
   id = 1
}
obj.obj = obj
-- Cannot serialise, excessive nesting
-- ngx.say(cjson.encode(obj), "<br/>")
local cjson_safe = require("cjson.safe")
--nil
-- ngx.say(cjson_safe.encode(obj), "<br/>")
logger:testLogger(cjson_safe.encode(obj))