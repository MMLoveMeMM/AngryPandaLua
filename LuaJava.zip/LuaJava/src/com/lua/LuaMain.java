package com.lua;

import java.util.logging.Logger;

import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.jse.JsePlatform;

import com.lua.data.Users;

public class LuaMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String luaStr = "print 'hello,world!'";
		Globals globals = JsePlatform.standardGlobals();
		LuaValue chunk = globals.load(luaStr);
		chunk.call();
		
		// loadLoginScript();
		// luajavaCreateInstance();
		// luajavaCreateInstance1();
		// luajavaCreateInstance2();
		// luajavaProxy();
		// luajavacJson();
		luajavaCreateInstance3();
		
	}
	
	public static void loadLoginScript() {
		String luaPath = "lua/login.lua";   //lua�ű��ļ�����·��
		Globals globals = JsePlatform.standardGlobals();
		//���ؽű��ļ�login.lua��������
		globals.loadfile(luaPath).call();
		//��ȡ�޲κ���hello
		LuaValue func = globals.get(LuaValue.valueOf("hello"));
		//ִ��hello����
		func.call();
		//��ȡ���κ���test
		LuaValue func1 = globals.get(LuaValue.valueOf("test"));
		//ִ��test����,����String���͵Ĳ�������
		String data = func1.call(LuaValue.valueOf("I'am from Java!")).toString();
		//��ӡlua�����ش�������
		System.out.println("data return from lua is:"+data);
		Users user=new Users();
		user.setName("liuzhibao");
		user.setYear(23);
		
		LuaValue func2 = globals.get(LuaValue.valueOf("testUser"));
		String da = func2.invoke(LuaValue.userdataOf(user)).toString();
	}
	
	public static void luajavaCreateInstance() {
		Globals globals = JsePlatform.standardGlobals();
		globals.loadfile("lua/test.lua").call();
	}
	
	public static void luajavaCreateInstance1() {
		Globals globals = JsePlatform.standardGlobals();
		globals.loadfile("lua/test1.lua").call();
	}
	
	public static void luajavaCreateInstance2() {
		Globals globals = JsePlatform.standardGlobals();
		globals.loadfile("lua/test2.lua").call();
	}
	
	public static void luajavaProxy() {
		Globals globals = JsePlatform.standardGlobals();
		globals.loadfile("lua/proxy.lua").call();
	}
	
	public static void luajavacJson() {
		Globals globals = JsePlatform.standardGlobals();
		globals.loadfile("lua/test_cjson.lua").call();
	}
	
	public static void luajavaCreateInstance3() {
		Globals globals = JsePlatform.standardGlobals();
		globals.loadfile("lua/test2.lua;lua/test1.lua").call();
	}

}
