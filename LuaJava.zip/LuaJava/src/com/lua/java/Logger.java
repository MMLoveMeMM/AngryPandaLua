package com.lua.java;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Logger {
    public static String TAG = "Logger";
    private static Log logger = LogFactory.getLog(Logger.class);;
    public Logger(){
        if(logger == null){
            logger = LogFactory.getLog(Logger.class);
        }
    }

    public void testLogger(String str) {
        logger.info(str);
    }

    public static void info(String content){
        logger.info(content);
    }
}